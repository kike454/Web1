var express = require('express');
var router = express.Router();
const database  = require('../database');
const games = require('../database/models/games.model'); 
require('dotenv').config(); 

/* GET home page. */
router.get('/', function(req, res, next) {
  if (req.session.user) {
    res.render('restricted', { title: 'Restricted', user: req.session.user, db: database.users.data });
} else {
    res.redirect('/login');
}
});

//console.log(database.users.data)
//console.log("onoijkn", database.users)
/*
router.post('/score',  async function(req, res, next) {
  const db = database.users.data
  const user = db[req.session.user]; 
  scoreReceived = req.body.score;

  if(!user){
    return res.status(404).json({ message: 'User not found' });
  }

  user.score += scoreReceived;
  //res.render('restricted');

  return res.status(200).json({ message: 'Score updated successfully', user: req.session.user, score: user.score });
  
  

});
*/
router.post('/gamesScore', (req, res) => {
  const { game, score } = req.body;

  // Obtener la lista de juegos desde la variable de entorno
  const validGames = process.env.GAMES.split(',');
  
  // Validar que el juego sea válido
  if (!validGames.includes(game)) {
    return res.status(400).json({ message: `El juego ${game} no está permitido.` });
  }

  // Validar que el score sea un entero positivo
  if (!Number.isInteger(score) || score < 0) {
    return res.status(400).json({ message: `El score debe ser un entero positivo.` });
  }

  // Registrar el juego y el score
  try {
    games.save(game, score);
    console.log(`Juego registrado: ${game}, Score: ${score}`);
    res.status(200).json({ message: 'Juego y score registrados correctamente.' });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
});

module.exports = router;